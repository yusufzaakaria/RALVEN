# RALVEN 5.0 - IDX Equity Research

Current release: [Operating guide](USER_GUIDE_5.md) and [implementation status and limitations](RELEASE_5.md). The sections below preserve historical 4.x methodology notes; the version 5 documents take precedence.

### Research page update

Valuation and Forecast have separate page implementations. Valuation explains method values versus observed market price, method weights, the enterprise/book-to-common-equity waterfall, discount/terminal inputs and the deterministic scenario range. Forecast shows selectable actual/projection trends, a five-year operating schedule, cash allocation or the residual-income ROE fade, and operating/payout inputs. Controls follow the active method: banks using DDM expose earnings growth and payout, without corporate EBIT-margin, D&A or capex controls. Reset affects the current page's inputs; a blocked model offers a full estimate reset.

Relative-only forecasts are explicitly labelled mechanical planning cases. They compound the selected current multiple denominators at the planning growth rate and do not feed the trailing-multiple valuation or recommendation. Excel includes their linked Planning Forecast formulas. Unsupported/blocked models display requirements rather than fabricated projections. Charts distinguish reported annual/TTM observations from analyst forecast periods; missing history is not bridged with a line. Corporate FCFF charts do not imply a net-income forecast. Market prices and per-share valuation charts use IDR/share; cash/equity waterfalls and operating charts use IDR billions.

## Statement explorer and analysis coverage

The Data page now includes an issuer-specific source statement explorer. It preserves every numeric non-dimensional consolidated fact from the available cached IDX instances, including lines outside the valuation adapter. Select an annual/interim filing, filter its line groups or search a taxonomy item. Columns retain their exact start/end dates, native units and context IDs. Nil is explicitly unreported, never zero. The explorer is a saved source archive; refreshing a valuation feed does not silently relabel its retrieval date. Dimensional segment/note breakdowns and PDF-only disclosures are not extracted by this register.

The latest rebuild contains 1,804 filings, 419,625 numeric facts and supported primary data for 924 of the 962 directory issuers. A targeted 2024/2025/2026 annual retry recovered 12 filings for 10 additional issuers, including non-calendar fiscal years. Some recovered periods are old. There are still 38 issuers without a supported primary statement. This is not complete-current-statement coverage. `/data/completeness.csv` lists missing/partial/conflicting model fields and analysis availability issuer by issuer.

Sensitivity and tornado analysis now follow the active model: discount rate/terminal growth for blended DCF or DDM; peer multiples/subject denominators for relative pricing; cost of equity/starting ROE for residual income. Tornado shocks preserve fixed method weights and reconcile enterprise claims. The center matrix cell must reproduce the base fair value. The current audit verifies sensitivity, tornado and Monte Carlo for all 683 eligible valuation outcomes; 153 technical-only signals and 126 blocked decisions do not receive fabricated valuation charts.

Excel includes formula-driven Valuation Sensitivity, documented Tornado stress snapshots, and a Source Statement Facts register with original units. PDF reports include method-specific sensitivity and tornado exhibits. Source classification, peer membership and source archive refresh remain documented update steps, not independent Excel source verification.

Maintenance commands (Node.js 24+, internet for retrieval):
```
node scripts/retry-statement-gaps.mjs
node scripts/build-statement-register.mjs --incremental
node scripts/update-coverage.mjs
node scripts/audit-completeness.mjs
node --test tests/*.test.mjs
node build.mjs
node scripts/validate-artifact.mjs
```
Use `node scripts/build-statement-register.mjs` for a full remap after parser changes. Incremental mode adds filings only; it does not reparse existing equal-count archives. The statement register builder requires the downloaded source XML cache in the sibling `qa/xbrl-v4` directory. The packaged per-issuer archives work without that cache.

Public application: https://ralven-equity-terminal.airycoot8.chatgpt.site/

Run with Node.js 24+: `node server.mjs`, then open http://127.0.0.1:4173. No dependency installation is required. Live retrieval needs internet access to public IDX and Yahoo endpoints; availability and redistribution are subject to those providers. No paid data subscription is bundled. The public website remains public.

## Decisions and assurance

Every directory issuer receives a typed decision and an explanation. The bundled 24 October 2026 audit has 962 issuers. The packaged audit has 329 source-checked valuation outputs, 354 conditional valuation outputs, 153 technical signals and 126 WAIT decisions (123 missing/stale quotes, one capital-impairment guard, one comparative source-scale conflict and one used-input source conflict). Read `public/data/coverage.json` for exact counts. Directory processing, supported statement extraction and investment recommendation coverage are different measures.

- FUNDAMENTAL: an eligible valuation with its required source checks passed. This is a model estimate, not independent certification of fair value.
- INDICATIVE: BUY/HOLD/SELL implied by a valuation, qualified by specific evidence, comparable, accounting or sector assumptions. Assurance is LOW.
- TECHNICAL: BUY/HOLD/SELL from observed-price indicators only. Assurance is LOW; no fundamental fair value, valuation upside or valuation Monte Carlo is produced.
- UNRATED / WAIT: a current quote, eligible model or an essential consistency check is missing. WAIT means defer the trading decision. It is never silently converted to HOLD. The UI lists required fixes under Model Integrity.

Hard blocks remain for missing/stale market quotes, invalid units/dates/assumptions, material discrepancies in used source figures, and a primary balance-sheet mismatch. A technical BUY is also withheld for negative equity. A zero-volume IDX summary does not reset an old last-trade date. Conditional calculations are allowed when supplied/provider evidence supports arithmetic but independent corroboration or business comparability is incomplete. Different source definitions are never averaged to manufacture agreement. A primary report and an IDX mirror count as one origin. Disputed corporate capital claims exclude DCF/EV methods; an independently usable direct-equity method or separately labelled technical signal can remain eligible.

## Data and update workflow

Inputs are IDR billions, shares billions and price IDR/share. Listed shares proxy diluted common shares; verify treasury shares, options, convertibles and corporate actions. Foreign statements use documented fiscal-date closing FX. This simplified translation is not an audited restatement or a forecast exchange-rate model.

Official IDX consolidated XBRL supplies supported financial facts. Yahoo supplies annual fundamentals and observed price history. The adapter excludes nil and dimensional segment facts, preserves full currency units, and maps explicit operating profit, full D&A, preferred stock, borrowing totals where available, and PPE/intangible cash expenditures. EBITDA is derived only where explicit operating profit and full D&A match the same context. Missing debt components, nil preferred claims and incomplete capex are not guessed or replaced with zero. Separate participant/temporary-syirkah funds and fund subtotals are reconciled using disclosed presentation candidates; the selected lines and residual are recorded. Funds are not added to parent book equity, counted twice or used as a balancing plug. PPE-only cash spending is not automatically called total sustaining capex.

TTM = prior annual + current YTD - matching prior YTD. All three facts must match currency, units and definition. Quarterly earnings are never multiplied by four. Annual EBITDA or debt is not carried into a newer TTM period. Source originals, publication/retrieval dates, FX and TTM components remain inspectable.

Opening a ticker refreshes its feeds. Cached results preserve dates. The universe screen is a dated snapshot; opening an issuer can legitimately change its result. There is no unattended scheduler configured. Repeated use does not rebuild the model.

Maintenance commands, from ralven/:

1. `node scripts/reconcile-sources.mjs --all` refreshes annual primary evidence; `--latest` refreshes the latest available interim. `--retry-latest` retries failed latest lookups.
2. `node scripts/remap-filings.mjs` re-extracts the stored filing URLs with the current mappings, preserving observations on failure. Raw XML is cached in sibling qa/xbrl-v4/. `--retry` retries interrupted downloads with backoff.
3. `node scripts/update-coverage.mjs` recalculates every issuer and writes dated CSV/JSON results.
4. `node --test tests/*.test.mjs`; `node build.mjs`; `node scripts/validate-artifact.mjs` validate arithmetic, source/decision policy and the Worker.

The earlier full market refresh scripts remain available. Inspect their checkpoints and archived catalogs before rerunning. A source failure is disclosed and is not counted as a successful extraction.

## Valuation methods

The methods are deterministic code, separate from inputs, assumptions and presentation.

- FCFF DCF: five-year unlevered cash flows and terminal reinvestment funded using g/ROIC. EV is reconciled to common equity by adding cash and subtracting debt, NCI and preferred claims. A valid corporate bridge is required.
- Financial services: direct equity DDM at cost of equity, plus eligible P/E and P/B. Deposits are not treated as corporate net debt. Regulatory capital and payout constraints still need issuer-specific review.
- Relative pricing: P/E for positive parent earnings; EV/EBITDA or EV/sales only with complete compatible capital claims and positive denominators. Financial firms may use P/B. An asset-heavy loss-making issuer may use P/B against loss-making positive-equity peers, with an accounting/asset-quality warning. Book equity is not appraised NAV or liquidation value.
- Residual income fallback: a profitable non-extractive company with parent book equity and at least two positive annual earnings observations can use book equity plus PV of excess earnings. Starting ROE uses matched average parent equity when available, otherwise closing parent equity; ROE fades to cost of equity over five years. Book growth follows retained earnings at the selected payout. Residual income after year five is zero. This is a disclosed competitive-return fade assumption, not an inferred reserve value or turnaround forecast.

Peers are selected from the same industry and sector, with subindustry and market-cap similarity prioritised. Up to 12 are retained. Annual/TTM trailing-year end dates may differ by at most 100 days, disclosed as conditional; YTD is excluded. Quotes must be within seven calendar days of valuation. Three eligible observations are required per used multiple. Caps: P/E and EV/EBITDA below 100x; P/B below 20x; EV/sales below 30x. These are transparent screens, not proof of economic comparability. No unrelated sector peers are silently added.

Stable positive operating CF supports 70% DCF/30% relative; unstable CF supports 40%/60%; financial services use 50%/50% when both qualify. A remaining eligible method gets 100%. Residual fallback uses 100% direct equity value when FCFF/industry peers are unavailable. Market price is the comparison reference, not an average component of fair value.

Commodity producers and exceptionally high expansion capex do not use generic perpetual DCF. Eligible trailing relative pricing can still provide an INDICATIVE signal. It is not a mining NAV: reserves, mine life, commodity-cycle normalization and expansion plans remain outside that model. Sources: https://pages.stern.nyu.edu/~adamodar/pdfiles/papers/commodity.pdf and https://pages.stern.nyu.edu/~adamodar/pdfiles/eqnotes/finsvc.pdf .

Valuation BUY: upside >=15%; SELL: downside <=-15%; HOLD between, with editable thresholds. Technical BUY: current price above SMA50, 63-session momentum above 5%, simple RSI14 below 75. Technical SELL: price below SMA50 and momentum below -5%; otherwise HOLD. At least 64 valid closes are required. Check corporate actions; simple unadjusted price signals can be distorted by splits, rights and unusual liquidity.

## Scenarios, sensitivity and Monte Carlo

Relative scenarios shock multiples -20%/+20% before the enterprise-to-equity bridge. Corporate DCF scenarios shock growth +/-3pp, margin +/-2.5pp and risk-free rate -/+1pp; financial margin shocks are inapplicable. Residual scenarios shock starting ROE -20%/+20% and Ke +1pp/-1pp. Sensitivity tables disclose the active method and axes.

Seeded Monte Carlo describes conditional model-value uncertainty, never future price probabilities. Defaults: 5,000 attempted draws; growth sigma 2.5pp, margin 2pp, rf 1pp, terminal g 0.5pp, lognormal multiples 15%; growth/margin correlation 0.35. Residual Monte Carlo instead shocks Ke and starting ROE with fixed payout/fade. Invalid draws are rejected and counted; equity is floored at zero. Technical/WAIT cases do not receive a fabricated fundamental distribution. Conditional valuations are simulated under their disclosed limitations.

## Imports and exports

Download the synthetic Excel template, replace inputs and cite sources, then upload .xlsx (5 MB maximum). Missing values remain blank; input formulas are rejected. Peer metadata and reporting basis are retained. Uploaded source claims, including restored JSON workspaces, are treated as user supplied until refreshed. Browser-local inputs are not a filing certification.

Excel exports contain formulas for the actual method: linked FCFF/DDM, peer multiples and equity bridges, residual clean-surplus roll-forward, or technical signal rules. Technical indicators recompute from exported price history when present; otherwise dated indicator snapshots are disclosed. Monte Carlo statistics are snapshots. Export-time policy and peer membership remain fixed; edit arithmetic in Excel but refresh/reimport to rescreen sources and membership. Formula outputs cannot certify documents.

PDF reports include the selected method, recommendation basis, assumptions, source evidence, limitations, applicable scenarios, peer exhibits and Monte Carlo where supported. EN/ID and light/dark modes remain available. AI assisted development/documentation; no LLM creates runtime financial facts or ratings.

Earlier v2/v3 packages and presentation files are dated examples and do not represent the v4 engine. This academic tool still requires human interpretation of assumptions, corporate actions, asset quality and peer comparability.

## Statement data update — 25 October 2026

The earlier 4.1 snapshot was re-extracted from 1,792 cached IDX filings for 962 directory issuers; 914 then had usable primary facts. The 4.2 archive and targeted retry counts are documented above. This is a mapping update, not a claim of newly published reports or fresh market quotes. Original retrieval and publication dates are retained.

Primary field coverage (at least one reporting period per issuer): operating profit 54 to 863; full D&A 25 to 148; EBITDA 1 to 141; eligible reconstructed financing debt 0 to 562. Disclosed borrowing components are available for 747 issuers. Counts overlap and do not certify full statement completeness.

Operating income is reconstructed only when classified face-statement components reconcile to reported pretax profit within XBRL rounding tolerance. Unknown numeric lines prevent reconstruction. Full D&A requires an explicit combined figure or both reported components. Borrowing components exclude note subtotals; unclassified other financial liabilities prevent their subtotal from becoming total debt. Nil values are never created as zero facts. Used reconstructed inputs make the valuation conditional.

Data now distinguishes derived facts, annual-only data, partial financing totals, unavailable conversions and sector-inapplicable metrics. Statement completeness and active-method input support are separate measures. Historical statement tables show actual periods without forecast columns. Expand source details for original amounts, formulas and reconciliation controls. Excel adds Derived Calculations (with formulas) and Statement History sheets.

TTM requires a matching immediately preceding annual period and comparable YTD pair. New primary annual reports do not relabel older provider facts. Archived provider depreciation-ratio inputs remain separately marked with unresolved definitions; they are not promoted to full D&A.

The deployment compresses JSON snapshots and initializes the provider only on an issuer API request. Formula/input checks and hard recommendation blocks remain active. Remaining limitations include untagged note/PDF disclosures, full D&A gaps, unclassified lease/funding components and issuers with unavailable primary filings.

Comparative source-scale validation blocks valuation when at least three same-period primary balance-sheet fields differ by a common factor of 1,000, 1,000,000 or 1,000,000,000 across filings. Original amounts remain inspectable; no automatic rescaling is applied. Conflicted issuers are excluded from peer screens. CAKK is blocked by this rule in the saved snapshot.
