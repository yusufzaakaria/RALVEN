# RALVEN 4.1 — User guide

Open https://ralven-equity-terminal.airycoot8.chatgpt.site/ or run `node server.mjs` with Node.js 24+ and visit http://127.0.0.1:4173. Internet access is required for live public IDX/Yahoo retrieval. Provider connectivity and availability vary. No paid data subscription or unattended refresh is bundled.

## Find and assess an issuer

Enter a four-character IDX ticker, select an issuer tab, or use Screener. An issuer refresh attempts live sources; dated saved evidence remains available on failure. EN/ID and theme preferences persist locally. The saved directory/quote audit is dated 24 October 2026; the statement mapping update is dated 25 October 2026.

The packaged directory contains 962 issuers; 924 have usable primary financial facts. Coverage means at least some supported facts, not complete statements. The 4.2 snapshot contains 329 source-checked valuation outputs, 354 conditional valuations, 153 technical outcomes and 126 WAIT outcomes. Opening an issuer can change its outcome if fresh sources differ.

## Read the Data page

Statement availability and input support for the selected valuation method are separate. For example, P/E can use one verified parent-profit denominator even when operating-profit or debt disclosures remain unresolved. A USED INPUTS CHECKED badge does not certify the entire statement.

- DERIVED: source components reconstruct the figure; expand the source for formulas and reconciliation controls.
- ANNUAL ONLY: historical annual data exists, but a compatible current TTM series is unavailable.
- PARTIAL: a component/subtotal is available, but the complete total remains unresolved. A borrowing lower bound is not usable as total debt.
- NOT APPLICABLE: the metric belongs to a different business model, such as bank NII for a poultry producer.
- NOT EXTRACTED: no compatible amount was obtained for the selected period. Additional notes/PDF disclosures or a documented import may be needed.
- FX / UNITS: a source figure exists without compatible conversion or units.
- CONFLICT / DEFINITION: source amounts or economic definitions materially differ; the difference remains visible.

Expand Annual cross-check and Latest interim statement facts to inspect the original periods. Historical tables show selected actual income-statement, balance-sheet and cash-flow items without forecast columns. Original amount, currency, units, XBRL tag, publication and retrieval dates remain attached to sources.

TTM = prior annual + current YTD − matching prior YTD. The annual period must immediately precede the YTD start date. Closing balances use their actual date. Older annual values are never relabelled current. Monetary model inputs are IDR billions, shares billions and price IDR/share. FX uses documented fiscal-date closing rates; this is not an audited currency restatement.

## Change assumptions and recalculate

Open Valuation or Edit assumptions. Change growth, margins, reinvestment, financing and terminal inputs; linked methods and simulations recalculate. The active method, weights and limitations are disclosed. DCF excludes incomplete capital bridges, invalid terminal inputs and unsupported generic commodity forecasts. Financial services use direct equity valuation. Relative valuation requires eligible peers; residual income and separately labelled technical signals are disclosed alternatives. See README.md for exact rules.

BUY/HOLD/SELL are model outputs with explicit assurance. Technical signals have no fundamental fair value. WAIT means required data/validation issues remain unresolved; it is not silently converted to HOLD.

## Import, save and export

Use Import in the navigation rail or Export / Import on mobile. Download the synthetic Excel template, replace data and provide source references. XLSX uploads are limited to 5 MB. Missing inputs remain missing and workbook input formulas are rejected. Imported source claims remain user-supplied.

Export model creates the valuation workbook with linked formulas, source evidence, availability explanations, Derived Calculations and Statement History. Derived Calculations uses component-level formulas in original reporting currency. Provider/peer membership and evidence policy are export-time snapshots; refresh/reimport to rescreen them. PDF reports retain source and method limitations. Save/load workspace uses JSON.

## Maintain and validate

Read README.md before running the source-reconciliation, remapping and coverage scripts. `node scripts/remap-filings.mjs` re-extracts saved filing URLs. New cache filenames include a URL hash; older cache files are reused only after their reporting periods match. Raw source retrieval dates remain separate from mapping dates.

Run `node scripts/update-coverage.mjs`, `node --test tests/*.test.mjs`, `node build.mjs`, and `node scripts/validate-artifact.mjs` before publication. JSON snapshots are compressed in the Worker; market data initializes only for an issuer API request. A broken feed does not count as a successful extraction.

AI assisted implementation and documentation. No LLM invents runtime financial facts or recommendation arithmetic. Remaining limitations include missing filings, untagged PDF disclosures, ambiguous financing/lease classifications, incomplete full D&A and business comparability.

Comparative source-scale validation blocks valuation when at least three same-period primary balance-sheet fields differ by a common factor of 1,000, 1,000,000 or 1,000,000,000 across filings. Original amounts remain inspectable; no automatic rescaling is applied. Conflicted issuers are excluded from peer screens. CAKK is blocked by this rule in the saved snapshot.
# RALVEN 4.2: source statements and risk exhibits

Open **Data → Source statement explorer** to view the saved original consolidated XBRL facts. Select a filing, search the taxonomy item, and optionally show nil disclosures. Amounts here are native source units, not the IDR-billion model amounts shown under Model Inputs & Reconciliation. Do not add repeated contexts or apply presentation rounding a second time. Line-group filters are search aids, not an official issuer statement classification. Original filing and retrieval dates remain visible.

Open **Sensitivity** for the active method's matrix, tornado drivers and Monte Carlo. Relative pricing varies peer multiples and matched subject denominators. Residual income varies starting ROE and cost of equity. DCF/DDM varies discount rate and terminal growth, preserving method weights. The outlined center cell is the base case. Tornado lower/higher refer to the input change, not always the valuation direction. Shocks are analyst stresses, not probabilities or issuer forecasts.

When a valuation chart is unavailable, use **Inspect missing inputs** to see the blocking evidence. Technical-only signals have no fundamental fair value. Import documented inputs through the Excel template or refresh supported feeds; missing values must never be replaced by assumed zero. Download the issuer-by-issuer gap audit from Data to review remaining statement and analysis gaps.

Excel downloads now include **Valuation Sensitivity**, **Tornado**, and **Source Statement Facts**. The sensitivity matrix contains formulas; tornado outputs are clearly identified as export-time snapshots. Refresh RALVEN and export again after source/peer changes. PDF downloads include method-specific matrix and tornado exhibits alongside existing valuation, source and simulation appendices.

## Separate Valuation and Forecast pages

**Valuation** answers what the business is worth. Compare method bars with the market-price line, inspect weights and the equity waterfall, and edit discount/terminal assumptions or rating thresholds. Corporate EV claims are excluded from bank DDM equity bridges. Open Sensitivity for the full matrix, tornado and Monte Carlo.

**Forecast** answers how the model's operating figures develop. Select a metric above the trend chart; reported actuals use solid green lines and projections use dashed blue lines. Review the cash allocation/ROE chart and the five-year schedule below. Edit operating inputs here: bank DDM uses earnings growth and payout; corporate FCFF uses sales growth, margin, tax, D&A, capex and working capital; residual income uses payout with ROE fading to cost of equity.

For relative-only pricing, the Forecast page is a separate planning display. Growth changes forward denominator illustrations, not today's trailing-multiple fair value. The notice and exported Planning Forecast sheet make that separation explicit. The current page's reset button resets its own inputs; a blocked model offers a reset of all estimates.
