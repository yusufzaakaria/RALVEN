RALVEN typography

Roboto: interface labels, navigation, headings and explanatory text.
Roboto Mono: financial figures, prices, chart scales and formulas.

Variable, normal-width Latin fonts from Google Fonts, downloaded 24 October 2026.
Fonts are hosted locally; no Google Fonts network connection is required at runtime.

Definition source:
https://fonts.googleapis.com/css2?family=Roboto:wght@100..900&family=Roboto+Mono:wght@100..700&display=swap

Roboto-Latin.woff2:
https://fonts.gstatic.com/s/roboto/v51/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2

RobotoMono-Latin.woff2:
https://fonts.gstatic.com/s/robotomono/v31/L0x5DF4xlVMF-BfR8bXMIjhLq38.woff2

License copies: Roboto-OFL.txt and RobotoMono-OFL.txt.
https://github.com/google/fonts/tree/main/ofl/roboto
https://github.com/google/fonts/tree/main/ofl/robotomono
